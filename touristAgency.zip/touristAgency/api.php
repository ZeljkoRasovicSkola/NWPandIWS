<?php

require_once __DIR__.'/code/components/default/db.php';
require __DIR__.'/code/components/libraries/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail=new PHPMailer(true);

function getUsers()
{
 $query='SELECT * FROM users;';

 $stmt=$GLOBALS['pdo']->prepare($query);
 $stmt->execute();

 $result=$stmt->fetchAll();

 return $result;
}

function getUser($id)
{
 $query='SELECT * FROM users WHERE userID=:id LIMIT 1;';

 $stmt=$GLOBALS['pdo']->prepare($query);
 $stmt->bindValue(':id',$id,PDO::PARAM_INT);
 $stmt->execute();

 $result=$stmt->fetch();

 return $result;
}

function sendVerificationEmail($email,$firstname,$lastname,$token,$mail)
{
 $result=false;
 $subject="Email verification";
 $url="https://wmi.stud.vts.su.ac.rs/code/components/signUp/verifyEmail.php?token=";
 $HTMLContent=
  '
   <div style="background:#18191f;">
    <br>
    <div style="background:#3d3f4f;">
     <div style="display:flex;justify-content:center;">
      <h3 style="color:#e9e9e9;padding:1rem;">Hi '.htmlspecialchars($firstname).' '.htmlspecialchars($lastname).', you have signed up.</h3>
     </div>
     <br>
     <div style="display:flex;justify-content:center;">
      <p style="color:#e9e9e9;">Please, verify your email address with the link given below.</p>
     </div>
     <br>
     <div style="display:flex;justify-content:center;">
      <a href="'.$url.$token.'" style="color:gold;">Activation link</a>
     </div>
     <br>
    </div>
    <br>
   </div>
  ';
 $content="Hi ".$firstname." ".$lastname.", you have signed up.\r\nPlease, verify your email address with the link given below.\r\n\r\nActivation link: ".$url.$token;
 try
 {
  $mail->isSMTP();
  $mail->Host='smtp.gmail.com';
  $mail->SMTPAuth=true;
  $mail->SMTPSecure=PHPMailer::ENCRYPTION_STARTTLS;
  $mail->Port=587;
  $mail->Username='zeljkorasovicskola@gmail.com';
  $mail->Password='vzps icea dkvm ffkz';
  $mail->Priority=1;
  $mail->CharSet='UTF-8';
  $mail->Subject=$subject;
  $mail->setFrom('zeljkorasovicskola@gmail.com',$firstname." ".$lastname);
  $mail->addAddress($email);
  $mail->isHTML(true);
  $mail->Body=$HTMLContent;
  $mail->AltBody=$content;
  $mail->send();
  $result=true;
  return $result;
 }
 catch(Exception $e)
 {
  $result=false;
  header("Location: ../../pages/signup.php?signup=failedToSendAEmail");
  exit();
 }
}

function invalidDate($date)
{
 $format='Y-m-d';
 $dateTimeObject=DateTime::createFromFormat($format,$date);

 if($dateTimeObject && $dateTimeObject->format($format)===$date)
 {
  $result=false;
 }
 else
 {
  $result=true;
 }
 return $result;
}

function invalidName($name,$flag)
{
 $result=true;

 if($flag)
 {
  if(!(preg_match("/^[\p{L} \'-]{3,64}$/u",$name)))
   $result=true;
  else
   $result=false;
 }
 else
 {
  if(!(preg_match("/^[\p{L} \'-]{3,32}$/u",$name)))
   $result=true;
  else
   $result=false;
 }
 return $result;
}

function invalidPostalCode($postalCode)
{
 $result=true;

 if($postalCode==="none")
 {
  return false;
 }

 if (!preg_match("/^(none|[A-Z0-9][A-Z0-9\s\-]{1,20})$/i", $postalCode))
  $result=true;
 else
  $result=false;

 return $result;
}

function invalidAddress($address)
{
 $result=true;

 if (!preg_match("/^[\p{L}0-9\s,.'\-\/#]+$/u",$address) || (strlen($address)<=5 || strlen($address)>=128))
  $result=true;
 else
  $result=false;

 return $result;
}

function invalidCountryCode($code)
{
 $result=true;

 if($code==="none")
 {
  return false;
 }

 if(!(preg_match("/^(?:\d{1,3})(?:-\d{1,4})?$/",$code)))
  $result=true;
 else
  $result=false;

 return $result;
}

function invalidPhone($phone)
{
 $result=true;

 if(!(preg_match("/^(?:\+?\d{1,3}[-\s]?)?(?:\d[-\s]?){7,15}\d$/",$phone)))
  $result=true;
 else
  $result=false;

 return $result;
}

function invalidEmail($email)
{
 $result=true;
 
 if(!(filter_var($email,FILTER_VALIDATE_EMAIL)))
  $result=true;
 else
  $result=false;

 return $result;
}

function existingEmail($email)
{
 $result=false;

 $sql="SELECT userID FROM users WHERE userEmail=:email LIMIT 1;";

 $stmt=$GLOBALS["pdo"]->prepare($sql);
 $stmt->bindParam(":email",$email);
 $stmt->execute();
 $answer=$stmt->fetch();

 if($answer)
  $result=true;
 else
  $result=false;

 return $result;
}

function invalidPassword($password)
{
 $result=true;
 
 if(!preg_match("/^[\S]{8,64}$/u",$password))
  $result=true;
 else
  $result=false;
 
 return $result;
}

function addUser($firstname,$lastname,$birthdate,$country,$countryCode,$city,$postalCode,$address,$phone,$email,$password,$mail)
{
 $countryCode=ltrim($countryCode,'+');

 if($countryCode==="" && $postalCode==="")
 {
  $sql='SELECT countryID FROM countries WHERE countryName=:countryName LIMIT 1;';
  $stmt=$GLOBALS["pdo"]->prepare($sql);
  $stmt->bindParam(":countryName",$country);
  $stmt->execute();
  $row=$stmt->fetch();
  $countryID= $row ? $row['countryID']: NULL;

  $sql='SELECT cityID FROM cities WHERE cityName=:cityName LIMIT 1;';
  $stmt=$GLOBALS["pdo"]->prepare($sql);
  $stmt->bindParam(":cityName",$city);
  $stmt->execute();
  $row=$stmt->fetch();
  $cityID= $row ? $row['cityID']: NULL;
 }
 else if($countryCode==="" && $postalCode!=="")
 {
  $sql='SELECT countryID FROM countries WHERE countryName=:countryName LIMIT 1;';
  $stmt=$GLOBALS["pdo"]->prepare($sql);
  $stmt->bindParam(":countryName",$country);
  $stmt->execute();
  $row=$stmt->fetch();
  $countryID= $row ? $row['countryID']: NULL;

  $sql="SELECT cityID FROM cities WHERE cityName=:cityName AND postalCode=:postalCode LIMIT 1;";
  $stmt=$GLOBALS["pdo"]->prepare($sql);
  $stmt->bindParam(":cityName",$city);
  $stmt->bindParam(":postalCode",$postalCode);
  $stmt->execute();
  $existingCity=$stmt->fetch();

  if($existingCity)
  {
   $cityID=$existingCity['cityID'];
  }
  else
  {
   $sql="INSERT INTO cities (cityName, postalCode, countryID) VALUES (:cityName,:postalCode,:countryID)";
   $stmt=$GLOBALS["pdo"]->prepare($sql);
   $stmt->bindParam(":cityName",$city);
   $stmt->bindParam(":postalCode",$postalCode);
   $stmt->bindParam(":countryID",$countryID);
   $stmt->execute();
   $cityID=$GLOBALS["pdo"]->lastInsertId();
  }
 }
 else
 {
  $sql="SELECT countryID FROM countries WHERE countryName=:countryName LIMIT 1;";
  $stmt=$GLOBALS["pdo"]->prepare($sql);
  $stmt->bindParam(":countryName",$country);
  $stmt->execute();
  $existingCountry=$stmt->fetch();

  if($existingCountry)
  {
   $countryID=$existingCountry['countryID'];
  }
  else
  {
   $sql="INSERT INTO countries (countryFlag,countryName,countryCode) VALUES ('🏴‍☠️',:countryName,:countryCode)";
   $stmt=$GLOBALS["pdo"]->prepare($sql);
   $stmt->bindParam(":countryName",$country);
   $stmt->bindParam(":countryCode",$countryCode);
   $stmt->execute();
   $countryID=$GLOBALS["pdo"]->lastInsertId();
  }

  $sql="SELECT cityID FROM cities WHERE cityName=:cityName AND postalCode=:postalCode LIMIT 1;";
  $stmt=$GLOBALS["pdo"]->prepare($sql);
  $stmt->bindParam(":cityName",$city);
  $stmt->bindParam(":postalCode",$postalCode);
  $stmt->execute();
  $existingCity=$stmt->fetch();

  if($existingCity)
  {
   $cityID=$existingCity['cityID'];
  }
  else
  {
   $sql="INSERT INTO cities (cityName, postalCode, countryID) VALUES (:cityName,:postalCode,:countryID)";
   $stmt=$GLOBALS["pdo"]->prepare($sql);
   $stmt->bindParam(":cityName",$city);
   $stmt->bindParam(":postalCode",$postalCode);
   $stmt->bindParam(":countryID",$countryID);
   $stmt->execute();
   $cityID=$GLOBALS["pdo"]->lastInsertId();
  }

  if(!$countryID)
   $countryID=NULL;

  if(!$cityID)
   $cityID=NULL;
 }

 $sql="INSERT INTO users(userEmail,userPassword,userToken,userFirstname,userLastname,userBirthDate,userPhone,userAddress,countryID,cityID) VALUES (:email,:password,:token,:firstname,:lastname,:birthdate,:phone,:address,:countryID,:cityID);";

 $options=['cost'=>12];
 $hashedPass=password_hash($password,PASSWORD_BCRYPT,$options);

 $token=md5(rand());

 $stmt=$GLOBALS["pdo"]->prepare($sql);
 $stmt->bindParam(":email",$email);
 $stmt->bindParam(":password",$hashedPass);
 $stmt->bindParam(":token",$token);
 $stmt->bindParam(":firstname",$firstname);
 $stmt->bindParam(":lastname",$lastname);
 $stmt->bindParam(":birthdate",$birthdate);
 $stmt->bindParam(":phone",$phone);
 $stmt->bindParam(":address",$address);
 $stmt->bindParam(":countryID",$countryID);
 $stmt->bindParam(":cityID",$cityID);
 $result=$stmt->execute();

 if($result)
  $userID=$GLOBALS["pdo"]->lastInsertId();

 else
  return false;

 $sql="INSERT INTO profileImages(userID) VALUES (:id)";

 $stmt=$GLOBALS["pdo"]->prepare($sql);
 $stmt->bindParam(":id",$userID);
 $answer=$stmt->execute();

 if($answer)
 {
  $send=sendVerificationEmail($email,$firstname,$lastname,$token,$mail);

  if($send)
   return $userID;

  else
   return false;
 }
 else
  return false;
}

function editUser($id,$firstname,$lastname,$birthdate,$country,$countryCode,$city,$postalCode,$address,$phone,$mail)
{
 $countryCode=ltrim($countryCode,'+');

 if($countryCode==="" && $postalCode==="")
 {
  $sql='SELECT countryID FROM countries WHERE countryName=:countryName LIMIT 1;';
  $stmt=$GLOBALS["pdo"]->prepare($sql);
  $stmt->bindParam(":countryName",$country);
  $stmt->execute();
  $row=$stmt->fetch();
  $countryID= $row ? $row['countryID']: NULL;

  $sql='SELECT cityID FROM cities WHERE cityName=:cityName LIMIT 1;';
  $stmt=$GLOBALS["pdo"]->prepare($sql);
  $stmt->bindParam(":cityName",$city);
  $stmt->execute();
  $row=$stmt->fetch();
  $cityID= $row ? $row['cityID']: NULL;
 }
 else if($countryCode==="" && $postalCode!=="")
 {
  $sql='SELECT countryID FROM countries WHERE countryName=:countryName LIMIT 1;';
  $stmt=$GLOBALS["pdo"]->prepare($sql);
  $stmt->bindParam(":countryName",$country);
  $stmt->execute();
  $row=$stmt->fetch();
  $countryID= $row ? $row['countryID']: NULL;

  $sql="SELECT cityID FROM cities WHERE cityName=:cityName AND postalCode=:postalCode LIMIT 1;";
  $stmt=$GLOBALS["pdo"]->prepare($sql);
  $stmt->bindParam(":cityName",$city);
  $stmt->bindParam(":postalCode",$postalCode);
  $stmt->execute();
  $existingCity=$stmt->fetch();

  if($existingCity)
  {
   $cityID=$existingCity['cityID'];
  }
  else
  {
   $sql="INSERT INTO cities (cityName, postalCode, countryID) VALUES (:cityName,:postalCode,:countryID)";
   $stmt=$GLOBALS["pdo"]->prepare($sql);
   $stmt->bindParam(":cityName",$city);
   $stmt->bindParam(":postalCode",$postalCode);
   $stmt->bindParam(":countryID",$countryID);
   $stmt->execute();
   $cityID=$GLOBALS["pdo"]->lastInsertId();
  }
 }
 else
 {
  $sql="SELECT countryID FROM countries WHERE countryName=:countryName LIMIT 1;";
  $stmt=$GLOBALS["pdo"]->prepare($sql);
  $stmt->bindParam(":countryName",$country);
  $stmt->execute();
  $existingCountry=$stmt->fetch();

  if($existingCountry)
  {
   $countryID=$existingCountry['countryID'];
  }
  else
  {
   $sql="INSERT INTO countries (countryFlag,countryName,countryCode) VALUES ('🏴‍☠️',:countryName,:countryCode)";
   $stmt=$GLOBALS["pdo"]->prepare($sql);
   $stmt->bindParam(":countryName",$country);
   $stmt->bindParam(":countryCode",$countryCode);
   $stmt->execute();
   $countryID=$GLOBALS["pdo"]->lastInsertId();
  }

  $sql="SELECT cityID FROM cities WHERE cityName=:cityName AND postalCode=:postalCode LIMIT 1;";
  $stmt=$GLOBALS["pdo"]->prepare($sql);
  $stmt->bindParam(":cityName",$city);
  $stmt->bindParam(":postalCode",$postalCode);
  $stmt->execute();
  $existingCity=$stmt->fetch();

  if($existingCity)
  {
   $cityID=$existingCity['cityID'];
  }
  else
  {
   $sql="INSERT INTO cities (cityName, postalCode, countryID) VALUES (:cityName,:postalCode,:countryID)";
   $stmt=$GLOBALS["pdo"]->prepare($sql);
   $stmt->bindParam(":cityName",$city);
   $stmt->bindParam(":postalCode",$postalCode);
   $stmt->bindParam(":countryID",$countryID);
   $stmt->execute();
   $cityID=$GLOBALS["pdo"]->lastInsertId();
  }

  if(!$countryID)
   $countryID=NULL;

  if(!$cityID)
   $cityID=NULL;
 }

 $result=getUser($id);

 if(empty($result))
  return false; 

 $firstname=empty(trim($firstname))?$result['userFirstname']:$firstname;

 $lastname=empty(trim($lastname))?$result['userLastname']:$lastname;

 $birthdate=empty(trim($birthdate))?$result['userBirthDate']:$birthdate;

 $countryID=empty(trim($countryID))?$result['countryID']:$countryID;

 $cityID=empty(trim($cityID))?$result['cityID']:$cityID;

 $address=empty($address)?$result['userAddress']:$address;

 $phone=empty(trim($phone))?$result['userPhone']:$phone;

 $pdo=$GLOBALS['pdo'];

 $query='UPDATE users SET userFirstname=:firstname,userLastname=:lastname,userBirthDate=:birthdate,userPhone=:phone,userAddress=:address,countryID=:countryID,cityID=:cityID WHERE userID=:id;';

 $stmt=$pdo->prepare($query);
 $stmt->bindValue(':id',$id);
 $stmt->bindValue(':firstname',$firstname);
 $stmt->bindValue(':lastname',$lastname);
 $stmt->bindValue(':birthdate',$birthdate);
 $stmt->bindValue(':countryID',$countryID);
 $stmt->bindValue(':cityID',$cityID);
 $stmt->bindValue(':address',$address);
 $stmt->bindValue(':phone',$phone);
 $res=$stmt->execute();

 if($res)
  return $id;

 else
  return false;
}

function deleteUser($id)
{
 $query='DELETE FROM users WHERE userID=:id LIMIT 1;';

 $stmt=$GLOBALS['pdo']->prepare($query);
 $stmt->bindValue(':id',$id,PDO::PARAM_INT);
 $res=$stmt->execute();
 return $res;
}

function getFirstToken()
{
 $pdo=$GLOBALS['pdo'];
 $query='SELECT * FROM tokens LIMIT 1;';
 $stmt=$pdo->prepare($query);
 $stmt->execute();

 $result=$stmt->fetch();

 return $result;
}

function getAllTokens()
{
 $pdo=$GLOBALS['pdo'];
 $query='SELECT * FROM tokens;';
 $stmt=$pdo->prepare($query);
 $stmt->execute();

 $result=$stmt->fetchAll();

 return $result;
}
function deleteToken($id)
{
 $pdo=$GLOBALS['pdo'];
 $query='DELETE FROM tokens WHERE id_token=:id LIMIT 1;';

 $stmt=$pdo->prepare($query);
 $stmt->bindValue(':id',$id,PDO::PARAM_INT);
 $stmt->execute();
}

header('Access-Control-Allow-Origin:*');
header('Content-Type:application/json; charset=UTF-8');
header('Access-Control-Allow-Method:GET,POST,PATCH,DELETE');
header('Access-Control_Allow_Headers:Content-Type,Access-Control-Allow-Headers,Authorization,X-Request-With');

$isOK=0;
$date=date('Y-m-d H:i:s');

do
{
 $token=getFirstToken();

 if($token['date_expires']<$date)
 {
  deleteToken($token['id_token']);
 }   
 else
 {
  $isOK++;
 }
}while($isOK<1);

$authorization="";
$auth=0;
$tokens=getAllTokens();
$preText="Bearer ";
$headers=getallheaders();

if(isset($headers["Authorization"]))
{
 $authorization=trim($headers["Authorization"]);

 foreach($tokens as $token)
 {
  if(($preText.$token['token'])===$authorization)
  {
   $auth=1;
  }
 }
}

if($auth)
{
 $method=$_SERVER["REQUEST_METHOD"];
 $parts=explode("/", $_SERVER["REQUEST_URI"]);
 $position=array_search("user", $parts);

 
 if(!$position)
 {
  $message='Please enter a proper endpoint';
  $data=['status'=>422,'message'=>$message];
  header("HTTP/1.0 422 Unprocessable Entity");
  echo json_encode($data);
  exit();
 }

 $id=$parts[$position+1]??null;
 
 if($method==="GET")
 {
  if(isset($id))
  {
   $user=getUser((int)$id);
   if($user===false)
   {
    $message="Inserted id is not in table";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   else
   {
    $data=['status'=>200,'message'=>'User fetched successfully','data'=>$user];
    header("HTTP/1.0 200 OK");
    echo json_encode($data);
    exit();
   }
  }
  else
  {
   $users=getUsers();
   $data=['status'=>200,'message'=>'List of users fetched successfully','data'=>$users];
   header("HTTP/1.0 200 OK");
   echo json_encode($data);
   exit();
  }
 }
 else if($method==="POST")
 {
  $inputData=json_decode(file_get_contents("php://input"),1);
  if(empty($inputData))
  {
   $message='Please enter a firstname, lastname, birthdate, country, countryCode(optional), city, postalCode(optional), address, phone, email and password';
   $data=['status'=>422,'message'=>$message];
   header("HTTP/1.0 422 Unprocessable Entity");
   echo json_encode($data);
   exit();
  }
  else
  {
   $error=0;
   $message='Please enter';
   $firstname=$inputData['firstname']??null;
   $lastname=$inputData['lastname']??null;
   $birthdate=$inputData['birthdate']??null;
   $country=$inputData['country']??null;
   $countryCode=$inputData['countryCode']??null;
   $city=$inputData['city']??null;
   $postalCode=$inputData['postalCode']??null;
   $address=$inputData['address']??null;
   $phone=$inputData['phone']??null;
   $email=$inputData['email']??null;
   $password=$inputData['password']??null;
 
   if(empty(trim($firstname)))
   {
    $message.=" firstname";
    $error=1;
   }
   if(empty(trim($lastname)))
   {
    if($error)
    {
     $message.=", lastname";
    }
    else
    {
     $message.=" lastname";
    }
    $error=1;
   }
   if(empty(trim($birthdate)))
   {
    if($error)
    {
     $message.=", birthdate";
    }
    else
    {
     $message.=" birthdate";
    }
    $error=1;
   }
   if(empty(trim($country)))
   {
    if($error)
    {
     $message.=", country";
    }
    else
    {
     $message.=" country";
    }
    $error=1;
   }
   if(empty(trim($city)))
   {
    if($error)
    {
     $message.=", city";
    }
    else
    {
     $message.=" city";
    }
    $error=1;
   }
   if(empty(trim($address)))
   {
    if($error)
    {
     $message.=", address";
    }
    else
    {
     $message.=" address";
    }
    $error=1;
   }
   if(empty(trim($phone)))
   {
    if($error)
    {
     $message.=", phone";
    }
    else
    {
     $message.=" phone";
    }
    $error=1;
   }
   if(empty(trim($email)))
   {
    if($error)
    {
     $message.=", email";
    }
    else
    {
     $message.=" email";
    }
    $error=1;
   }
   if(empty(trim($password)))
   {
    if($error)
    {
     $message.=", password";
    }
    else
    {
     $message.=" password";
    }
    $error=1;
   }
 
   if($error)
   {
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(invalidName($firstname,0))
   {
    $message="Invalid firstname";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(invalidName($lastname,0))
   {
    $message="Invalid lastname";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(invalidDate($birthdate))
   {
    $message="Invalid birthdate";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(invalidName($country,0))
   {
    $message="Invalid country";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(!empty(trim($countryCode)) || $countryCode==="none")
   {
    if(invalidCountryCode($countryCode))
    {
     $message="Invalid countryCode";
     $data=['status'=>422,'message'=>$message];
     header("HTTP/1.0 422 Unprocessable Entity");
     echo json_encode($data);
     exit();
    }
   }
   if(invalidName($city,1))
   {
    $message="Invalid city";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(!empty(trim($postalCode)) || $countryCode==="none")
   {
    if(invalidPostalCode($postalCode))
    {
     $message="Invalid postalCode";
     $data=['status'=>422,'message'=>$message];
     header("HTTP/1.0 422 Unprocessable Entity");
     echo json_encode($data);
     exit();
    }
   }
   if(invalidAddress($address))
   {
    $message="Invalid address";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(invalidPhone($phone))
   {
    $message="Invalid phone";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(invalidEmail($email))
   {
    $message="Invalid email";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(existingEmail($email))
   {
    $message="Email alredy exist";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(invalidPassword($password))
   {
    $message="Invalid password";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }

   $id=addUser($firstname,$lastname,$birthdate,$country,$countryCode,$city,$postalCode,$address,$phone,$email,$password,$mail);

   $result=getUser($id);

   if(empty($result))
   {
    $data=['status'=>500,'message'=>'Server is unable to create a user'];
    header("HTTP/1.0 500 Internal Server Error");
    echo json_encode($data);
   }
   else
   {
    $data=['status'=>201,'message'=>'User successfully created','id'=>$id];
    header("HTTP/1.0 201 Created");
    echo json_encode($data);
   }
  }
 }
 elseif($method==="PATCH")
 {
  $inputData=json_decode(file_get_contents("php://input"),1);
  if(empty($inputData))
  {
   $message='Please enter a id and all things you wish to change to that user like firstname, lastname, birthdate, country, countryCode(optional), city, postalCode(optional), address, phone, email and password';
   $data=['status'=>422,'message'=>$message];
   header("HTTP/1.0 422 Unprocessable Entity");
   echo json_encode($data);
   exit();
  }
  else
  {
 if(isset($inputData['id']))
  {
   $id=$inputData['id'];
   $firstname=$inputData['firstname']??null;
   $lastname=$inputData['lastname']??null;
   $birthdate=$inputData['birthdate']??null;
   $country=$inputData['country']??null;
   $countryCode=$inputData['countryCode']??null;
   $city=$inputData['city']??null;
   $postalCode=$inputData['postalCode']??null;
   $address=$inputData['address']??null;
   $phone=$inputData['phone']??null;

   if(!empty(trim($firstname)) && invalidName($firstname,0))
   {
    $message="Invalid firstname";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(!empty(trim($lastname)) && invalidName($lastname,0))
   {
    $message="Invalid lastname";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(!empty(trim($birthdate)) && invalidDate($birthdate))
   {
    $message="Invalid birthdate";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(!empty(trim($country)) && invalidName($country,0))
   {
    $message="Invalid country";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(!empty(trim($countryCode)) || $countryCode==="none")
   {
    if(invalidCountryCode($countryCode))
    {
     $message="Invalid countryCode";
     $data=['status'=>422,'message'=>$message];
     header("HTTP/1.0 422 Unprocessable Entity");
     echo json_encode($data);
     exit();
    }
   }
   if(!empty(trim($city)) && invalidName($city,1))
   {
    $message="Invalid city";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(!empty(trim($postalCode)) || $countryCode==="none")
   {
    if(invalidPostalCode($postalCode))
    {
     $message="Invalid postalCode";
     $data=['status'=>422,'message'=>$message];
     header("HTTP/1.0 422 Unprocessable Entity");
     echo json_encode($data);
     exit();
    }
   }
   if(!empty(trim($address)) && invalidAddress($address))
   {
    $message="Invalid address";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
   if(!empty(trim($phone)) && invalidPhone($phone))
   {
    $message="Invalid phone";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }

   $id=editUser($id,$firstname,$lastname,$birthdate,$country,$countryCode,$city,$postalCode,$address,$phone,$mail);

   $result=getUser($id);

   if(empty($result))
   {
    $data=['status'=>500,'message'=>'Server is unable to edit a user'];
    header("HTTP/1.0 500 Internal Server Error");
    echo json_encode($data);
   }
   else
   {
    $data=['status'=>201,'message'=>'User is successfully edited','id'=>$id];
    header("HTTP/1.0 201 Created");
    echo json_encode($data);
   }
  }
  else
  {
   $message="Please insert a user id";
   $data=['status'=>422,'message'=>$message];
   header("HTTP/1.0 422 Unprocessable Entity");
   echo json_encode($data);
   exit();
  }
 }
 }
 elseif($method==="DELETE")
 {
  $inputData=json_decode(file_get_contents("php://input"),1);
  if(empty($inputData))
  {
   $message='Please enter id of the user';
   $data=['status'=>422,'message'=>$message];
   header("HTTP/1.0 422 Unprocessable Entity");
   echo json_encode($data);
   exit();
  }
  else
  {
   if(isset($inputData['id']))
   {
    $id=$inputData['id'];
    $user=deleteUser((int)$id);
    $data=['status'=>204,'message'=>'User is deleted successfully','data'=>$user];
    header("HTTP/1.0 204 content");
    echo json_encode($data);
    exit();
   }
   else
   {
    $message="Please enter a user id";
    $data=['status'=>422,'message'=>$message];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
   }
  }
 }
 else
 {
  $data=['status'=>405,'message'=>$method.' method is not allowed'];
  header("HTTP/1.0 405 Method Not Allowed");
  echo json_encode($data);
  exit();
 }
}
else
{
 $data=['status'=>401,'message'=>'Token is not valid!'];
 header("HTTP/1.0 401 Unauthorized");
 echo json_encode($data);
 exit();
}
?>

<!DOCTYPE html>
<html lang="en">
 <head>
 <meta charset="UTF-8">
 <title>User API Documentation</title>
 <style>
  body
  {
   margin:40px;
   background-color:#e9e9e9;
  }
  h1,h2
  {
   color:#333;
  }
  table
  {
   width:100%;
   border-collapse:collapse;
   background:#ffffff;
   margin-bottom:30px;
  }
  th,td
  {
   border:1px solid #3d3f4f;
   padding:12px;
   text-align:left;
  }
  th
  {
   background-color:#3d3f4f;
   color: white;
  }
  pre
  {
   background-color:#2d2d2d;
   color:#f8f8f2;
   padding:15px;
   overflow-x: auto;
   border-radius:5px;
  }
  code
  {
   font-family:monospace;
  }
  section
  {
   margin-bottom:40px;
  }
  .note
  {
   font-style:italic;
   color:#555;
  }
 </style>
</head>
<body>
 <h2>User API Documentation</h2>
 <section>
  <h2>API Endpoints</h2>
  <table>
   <thead>
    <tr>
     <th>Method</th>
     <th>Endpoint</th>
     <th>Description</th>
    </tr>
   </thead>
   <tbody>
    <tr><td>GET</td><td>/user</td><td>Get all users</td></tr>
    <tr><td>GET</td><td>/user/{id}</td><td>Get a specific user by ID</td></tr>
    <tr><td>POST</td><td>/user</td><td>Create a new user</td></tr>
    <tr><td>PATCH</td><td>/user</td><td>Update an existing user</td></tr>
    <tr><td>DELETE</td><td>/user</td><td>Delete a user</td></tr>
   </tbody>
  </table>
 </section>
 <section>
  <p>For post, the country code and postal code fields are optional.</p>
  <p>With the patch, only the id is required, not all fields need to be changed.</p>
 </section>
 <section>
  <h2>GET /user/{id}</h2>
  <h3>Request:</h3>
  <pre><code>curl -H "Authorization: Bearer -tokenOf80char-:2038f0777f89a3ed6dc9cb4fb0290dc32038f0777f89a3ed6dc9cb4fb0290dc3" \
https://https://wmi.stud.vts.su.ac.rs/api/user/6</code></pre>
  <h3>Response:</h3>
  <pre><code>{
  "status": 200,
  "message": "User fetched successfully",
  "data": {
    "userID": 6,
    "userEmail": "viliw61764@mv6a.com",
    "userPassword": "...",
    "userRole": "user",
    "userToken": "...",
    "userStatus": "pending",
    "userFirstname": "dkwodk",
    "userLastname": "tester",
    "userBirthDate": "2002-11-25",
    "userPhone": "381 62 439 1545",
    "userAddress": "Novosadska 20",
    "countryID": 157,
    "cityID": 5686,
    "userDateTimeAdded": "2025-09-29 22:42:37"
  }
}</code></pre>
 </section>
 <section>
  <h2>POST /user</h2>
  <h3>Request:</h3>
  <pre><code>curl -H "Authorization: Bearer -tokenOf80char-:2038f0777f89a3ed6dc9cb4fb0290dc32038f0777f89a3ed6dc9cb4fb0290dc3" \
-X POST https://https://wmi.stud.vts.su.ac.rs/api/user \
-H "Content-Type: application/json" \
-d '{
  "firstname": "zeljko",
  "lastname": "rasovic",
  "birthdate": "2003-10-25",
  "country": "Serbia",
  "address": "Sarajevska 90",
  "phone": "062 299 1045",
  "email": "vilwrwr1764@mv6a.com",
  "password": "haha12345"
}'</code></pre>
  <h3>Response:</h3>
  <pre><code>{
  "status": 201,
  "message": "User successfully created",
  "id": "11"
}</code></pre>
  <p class="note">You can confirm user creation by sending a GET request to `/user/11`.</p>
 </section>
 <section>
  <h2>PATCH /user</h2>
  <h3>Request:</h3>
  <pre><code>curl -H "Authorization: Bearer -tokenOf80char-:2038f0777f89a3ed6dc9cb4fb0290dc32038f0777f89a3ed6dc9cb4fb0290dc3" \
-X PATCH https://https://wmi.stud.vts.su.ac.rs/api/user \
-H "Content-Type: application/json" \
-d '{
  "id": 11,
  "firstname": "dkwodk",
  "lastname": "tester",
  "birthdate": "2002-11-25",
  "country": "Serbia",
  "countryCode": "381",
  "city": "Novi Sad",
  "postalCode": "21000",
  "address": "Novosadska 20",
  "phone": "381 62 439 1545"
}'</code></pre>
  <h3>Response:</h3>
  <pre><code>{
  "status": 201,
  "message": "User is successfully edited",
  "id": 11
}</code></pre>
 </section>
 <section>
  <h2>DELETE /user</h2>
  <h3>Request:</h3>
  <pre><code>curl -H "Authorization: Bearer -tokenOf80char-:2038f0777f89a3ed6dc9cb4fb0290dc32038f0777f89a3ed6dc9cb4fb0290dc3" \
-X DELETE https://https://wmi.stud.vts.su.ac.rs/api/user \
-H "Content-Type: application/json" \
-d '{"id": 11}'</code></pre>
  <h3>Response:</h3>
  <pre><code>// No content returned</code></pre>
  <p class="note">You can confirm deletion by sending a GET request to `/user/11`. You will receive:</p>
  <pre><code>{
  "status": 422,
  "message": "Inserted id is not in table"
}</code></pre>
 </section>
</body>
</html>

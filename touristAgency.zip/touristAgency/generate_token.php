<?php

require_once __DIR__.'/code/components/default/db.php';

date_default_timezone_set('Europe/Belgrade');

$text='';
$i=0;

for($i=0;$i<10;$i++)
{
 if($i%2)
 {
  $text.=chr(rand(97,122));
 }
 else
 {
  $text.=chr(rand(65,90));
 }
}

$token='-tokenOf80char-:'.md5($text).md5($text);
$date_expires=date('Y-m-d H:i:s',strtotime('+1 month'));

$pdo=$GLOBALS['pdo'];
$query='INSERT INTO tokens(token,date_expires) VALUES (:token,:date_expires);';

$stmt=$pdo->prepare($query);
$stmt->bindValue(':token',$token,PDO::PARAM_STR);
$stmt->bindValue(':date_expires',$date_expires,PDO::PARAM_STR);
$stmt->execute();

?>

<?php
 $title="Resend verification email";
 require __DIR__.'/../components/head/head.php';
?>
 <body>
  <?php require __DIR__.'/../components/nav/nav.php';?>
  <main class="bg">
   <?php require __DIR__.'/../components/signUp/resendVerificationEmail.php';?>
  </main>
 </body>
</html>

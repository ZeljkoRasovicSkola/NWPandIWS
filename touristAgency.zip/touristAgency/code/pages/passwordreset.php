<?php
 $title="Password reset";
 require __DIR__.'/../components/head/head.php';
?>
 <body>
  <?php require __DIR__.'/../components/nav/nav.php';?>
  <main class="bg">
   <?php require __DIR__.'/../components/logIn/passwordReset.php';?>
  </main>
 </body>
</html>

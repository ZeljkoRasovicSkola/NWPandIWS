<?php
 $profile=1;
 $title="Profile page";
 require __DIR__.'/../components/head/head.php';
?>
 <body>
  <?php require __DIR__.'/../components/nav/nav.php';?>
  <main class="bg">
   <?php require __DIR__.'/../components/profile/profile.php';?>
  </main>
 </body>
</html>

<?php
 $title="Sign up page";
 $signUp=1;
 require __DIR__.'/../components/head/head.php';
?>
 <body>
  <?php require __DIR__.'/../components/nav/nav.php';?>
  <main class="bg">
   <?php require __DIR__.'/../components/signUp/signUp.php';?>
  </main>
 </body>
</html>

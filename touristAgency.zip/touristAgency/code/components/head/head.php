<?php
 if(!isset($title))
 {
  $title="Tourist agency";
 }
 if(!isset($slider))
 {
  $slider=0;
 }
 if(!isset($signUp))
 {
  $signUp=0;
 }
 if(!isset($profile))
 {
  $profile=0;
 }
 if(!isset($admin))
 {
  $admin=0;
 }
 if(!isset($favorite))
 {
  $favorite=0;
 }
 if(!isset($tours))
 {
  $tours=0;
 }
?>
<!DOCTYPE html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow,noimageindex,nosnippet,noarchive,notranslate">
  <meta name="author" content="Zeljko Rasovic">
  <meta name="description" content="Tourist agency">
  <meta name="keywords" content="Tourist agency">
  <title><?php echo $title;?></title>
  <link rel="stylesheet" href="../components/nav/nav.css">
  <link rel="icon" type="image/x-icon" href="../../img/logos/logo.png">
  <?php
   if($slider)
   {
    echo'<link rel="stylesheet" href="../components/slider/slider.css">';
   }
   if($signUp)
   {
    echo'<link rel="stylesheet" href="../components/signUp/signUp.css">';
   }
   if($profile)
   {
    echo'<link rel="stylesheet" href="../components/profile/profile.css">';
   }
   if($admin)
   {
    echo'<link rel="stylesheet" href="../components/admin/admin.css">';
    echo'<link rel="stylesheet" href="../components/libraries/dataTables/dataTables.css">';
   }
   if($favorite)
   {
    echo'<link rel="stylesheet" href="../components/controlCenter/favorite.css">';
   }
   if($tours)
   {
    echo'<link rel="stylesheet" href="../components/controlCenter/tours.css">';
   }
  ?>
 </head>

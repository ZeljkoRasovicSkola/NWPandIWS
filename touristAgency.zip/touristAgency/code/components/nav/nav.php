<?php
 require_once __DIR__.'/../default/session.php';

 if(!isset($_SESSION["role"]))
 {
  $_SESSION["role"]="";
 }
?>
  <header class="header bg flex">
   <div class="flexLeft">
    <a href="index.php" id="logo"><img src="../../img/logos/logo.png" alt="Logo" width="40px" height="40px"></a>
    <a href="index.php" id="logoText"><h2>Tourist agency</h2></a>
   </div>
   <div class="flexCenter">
    <form method="GET" action="searchHandler.php" id="navSearchBar">
     <input type="text" placeholder="Search" name="search" id="navSearchBox">
     <input type="reset" value="&#10060;" id="navResetButton">
     <input type="submit" value="&#128269;" id="navSearchButton">
   </form>
   </div>
   <div class="flexRight">
    <label for="ham" id="hamMenu"><input type="checkbox" id="ham"></label>
    <?php
     if($_SESSION["role"]==="user")
     {
      echo '<nav id="dropdown" class="flexRight">';
      echo '<form method="GET" action="" id="searchBarHam">';
      echo '<input type="text" placeholder="Search" name="search" id="searchBoxHam">';
      echo '<input type="reset" value="&#10060;" id="resetButtonHam">';
      echo '<input type="submit" value="&#128269;" id="searchButtonHam">';
      echo '</form>';
      echo'<a href="tours.php">Tours</a>';
      echo'<a href="favorite.php">Favorite</a>';
      echo'<a href="profile.php">Profile</a>';
     }
     else if($_SESSION["role"]==="agency")
     {
      echo '<nav id="dropdown" class="flexRight">';
      echo '<form method="GET" action="" id="searchBarHam">';
      echo '<input type="text" placeholder="Search" name="search" id="searchBoxHam">';
      echo '<input type="reset" value="&#10060;" id="resetButtonHam">';
      echo '<input type="submit" value="&#128269;" id="searchButtonHam">';
      echo '</form>';
      echo'<a href="controlcenter.php">Control center</a>';
      echo'<a href="profile.php">Profile</a>';
     }
     else if($_SESSION["role"]==="admin")
     {
      echo '<nav id="dropdown" class="flexRight">';
      echo '<form method="GET" action="" id="searchBarHam">';
      echo '<input type="text" placeholder="Search" name="search" id="searchBoxHam">';
      echo '<input type="reset" value="&#10060;" id="resetButtonHam">';
      echo '<input type="submit" value="&#128269;" id="searchButtonHam">';
      echo '</form>';
      echo'<a href="admin.php">Admin</a>';
      echo'<a href="profile.php">Profile</a>';
     }
     else
     {
      echo '<nav id="dropdown" class="flexRight">';
      echo ' <form method="GET" action="" id="searchBarHam">';
      echo '<input type="text" placeholder="Search" name="search" id="searchBoxHam">';
      echo '<input type="reset" value="&#10060;" id="resetButtonHam">';
      echo '<input type="submit" value="&#128269;" id="searchButtonHam">';
      echo '</form>';
      echo'<a href="login.php">Log in</a>';
      echo'<a href="signup.php">Sign up</a>';
     }
    ?>
    </nav>
   </div>
  </header>
